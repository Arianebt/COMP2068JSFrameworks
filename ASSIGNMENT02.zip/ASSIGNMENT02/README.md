# recipe-sharing

This assignment requires you to create a new Node application using Express,MongoDB/Mongoose, and HBS views.
Your site must be hosted live on a cloud service such asRender (Recommended), Azure, Heroku, AWS, or Digital Ocean.
This Assignment counts for 25% of your final grade.
You will choose an idea for an applicationthat implements CRUD functionality.
Some examples include: Workout Tracker, AssignmentTracker, etc.
and then will write the code for this application to implement CRUD,authentication,
and one additional feature
